package com.zxn.mvpdemo;

import com.zxn.presenter.view.BaseActivity;

/**
 * Created by zxn on 2019/4/8.
 */
public abstract class MvpActivity extends BaseActivity {
    @Override
    public void showToast(int msg) {

    }

    @Override
    public void showToast(String msg) {

    }

    @Override
    public void showLoading(boolean cancelable) {

    }

    @Override
    public void showLoading(String msg, boolean cancelable) {

    }

    @Override
    public void showLoading(String msg) {

    }

    @Override
    public void showLoading(int msgResId) {

    }

    @Override
    public void closeLoading() {

    }
}
