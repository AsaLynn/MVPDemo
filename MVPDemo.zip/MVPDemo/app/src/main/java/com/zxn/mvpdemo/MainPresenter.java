package com.zxn.mvpdemo;

import com.zxn.presenter.presenter.BasePresenter;
import com.zxn.presenter.presenter.IView;

/**
 * Created by zxn on 2019/6/30.
 */
public abstract class MainPresenter<V extends IView> extends BasePresenter<V> {


//    @Override
//    public List<T> getData() {
//        return super.getData();
//    }


//    @Override
//    public List<?> getData() {
//        return super.getData();
//    }

}
