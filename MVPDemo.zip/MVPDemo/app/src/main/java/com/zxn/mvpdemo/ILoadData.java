package com.zxn.mvpdemo;

import java.util.List;

/**
 * Created by zxn on 2019/6/30.
 */
public interface ILoadData<T> {

    T getData();

}
