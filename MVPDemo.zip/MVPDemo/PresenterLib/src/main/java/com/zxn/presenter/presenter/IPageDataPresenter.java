package com.zxn.presenter.presenter;

import java.util.List;

/**
 * Created by zxn on 2019/7/12.
 */
public interface IPageDataPresenter<T> {

    List<T> getDataList();
}


